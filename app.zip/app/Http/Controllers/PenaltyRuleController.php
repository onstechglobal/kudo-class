<?php

namespace App\Http\Controllers;

use App\Models\PenaltyRuleModel;
use Illuminate\Http\Request;

class PenaltyRuleController extends Controller
{
    // 🔹 Get All
    public function index(Request $request){
        $schoolId = $request->school_id ?? 1;

        $rules = PenaltyRuleModel::where('school_id', $schoolId)
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'status' => true,
            'data' => $rules
        ]);
    }


    // 🔹 Store
    public function store(Request $request){
        $request->validate([
            'school_id' => 'required|integer',
            'fee_type' => 'required|string',
            'penalty_type' => 'required|in:flat,percentage',
            'penalty_value' => 'required|numeric|min:0',
            'applies_after_days' => 'required|integer|min:1',
            'frequency' => 'required|in:once,per_month'
        ]);

        $rule = PenaltyRuleModel::create([
            'school_id' => $request->school_id, // ✅ SAVE
            'fee_type' => $request->fee_type,
            'penalty_type' => $request->penalty_type,
            'penalty_value' => $request->penalty_value,
            'applies_after_days' => $request->applies_after_days,
            'frequency' => $request->frequency,
            'is_active' => $request->is_active ?? 1,
            'created_at' => now()
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Penalty Rule Created Successfully',
            'data' => $rule
        ]);
    }


    // 🔹 Get Single
    public function show($id){
        $rule = PenaltyRuleModel::find($id);

        if (!$rule) {
            return response()->json([
                'status' => false,
                'message' => 'Rule Not Found'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $rule
        ]);
    }


    // 🔹 Update
    public function update(Request $request, $id){
        $rule = PenaltyRuleModel::find($id);

        if (!$rule) {
            return response()->json([
                'status' => false,
                'message' => 'Rule Not Found'
            ], 404);
        }

        $request->validate([
            'school_id' => 'required|integer',
            'fee_type' => 'required|string',
            'penalty_type' => 'required|in:flat,percentage',
            'penalty_value' => 'required|numeric|min:0',
            'applies_after_days' => 'required|integer|min:1',
            'frequency' => 'required|in:once,per_month'
        ]);

        $rule->update($request->only([
            'school_id',
            'fee_type',
            'penalty_type',
            'penalty_value',
            'applies_after_days',
            'frequency',
            'is_active'
        ]));

        return response()->json([
            'status' => true,
            'message' => 'Penalty Rule Updated Successfully',
            'data' => $rule
        ]);
    }


    // 🔹 Delete
    public function destroy($id)
    {
        $rule = PenaltyRuleModel::find($id);

        if (!$rule) {
            return response()->json([
                'status' => false,
                'message' => 'Rule Not Found'
            ], 404);
        }

        $rule->delete();

        return response()->json([
            'status' => true,
            'message' => 'Penalty Rule Deleted Successfully'
        ]);
    }

}
