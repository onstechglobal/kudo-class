<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PenaltyRuleModel extends Model
{
    protected $table = 'tb_penalty_rules';
    public $timestamps = false;

    protected $fillable = [
        'school_id',
        'fee_type',
        'penalty_type',
        'penalty_value',
        'applies_after_days',
        'frequency',
        'is_active',
        'created_at'
    ];
}
