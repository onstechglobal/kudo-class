import React, { useState } from 'react';
import { Users, GraduationCap, Bus, Receipt, CheckCircle, ShieldCheck, ChevronLeft, ChevronRight } from 'lucide-react';
import AdminLayout from '../../layouts/AdminLayout';

const AdmissionForm = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [maxReachedStep, setMaxReachedStep] = useState(1);
  
  // Form State
  const [formData, setFormData] = useState({
    searchPhone: '',
    parentRelation: 'Father',
    parentName: '',
    parentEmail: '',
    parentPersonalPhone: '',
    parentType: 'Normal',
    address: '',
    studentName: '',
    dob: '',
    studentClass: 'Grade 1',
    transportRoute: '0'
  });

  const steps = [
    { id: 1, title: 'Family', icon: Users },
    { id: 2, title: 'Student', icon: GraduationCap },
    { id: 3, title: 'Transport', icon: Bus },
    { id: 4, title: 'Preview', icon: Receipt },
    { id: 5, title: 'Confirm', icon: CheckCircle },
  ];

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const navigateToStep = (stepId) => {
    if (stepId <= maxReachedStep) {
      setCurrentStep(stepId);
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length) {
      const next = currentStep + 1;
      setCurrentStep(next);
      if (next > maxReachedStep) setMaxReachedStep(next);
    } else {
      alert("Success! Admission complete.");
      window.location.reload();
    }
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const calculateFees = () => {
    const baseFee = 25000;
    const transport = parseFloat(formData.transportRoute);
    let discount = 0;
    if (formData.parentType === "Teacher") discount = baseFee * 0.15;
    else if (formData.parentType === "Staff") discount = baseFee * 0.10;
    
    return {
      baseFee,
      discount,
      transport,
      total: baseFee - discount + transport
    };
  };

  const fees = calculateFees();

  return (
    <AdminLayout>
        <div className="min-h-screen bg-slate-50 p-4 md:p-8 text-slate-800 font-sans">
        <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="mb-8 text-center md:text-left">
            <p className="text-xs font-bold text-blue-600 tracking-widest uppercase mb-1">Admissions / New</p>
            <h1 className="text-3xl font-bold">New Admission Registration</h1>
            </div>

            {/* Step Indicator */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex justify-between mb-8 overflow-x-auto gap-4 scrollbar-hide">
            {steps.map((step) => {
                const Icon = step.icon;
                const isActive = currentStep === step.id;
                const isVisited = step.id <= maxReachedStep;
                const isCompleted = step.id < currentStep;

                return (
                <button
                    key={step.id}
                    onClick={() => navigateToStep(step.id)}
                    disabled={!isVisited}
                    className={`flex items-center gap-3 transition-all flex-shrink-0 ${
                    isActive ? 'text-blue-600' : isVisited ? 'text-emerald-500 cursor-pointer' : 'text-slate-400 cursor-not-allowed opacity-50'
                    }`}
                >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                    isActive ? 'bg-blue-600 text-white' : isCompleted ? 'bg-emerald-500 text-white' : 'bg-slate-100'
                    }`}>
                    <Icon size={18} />
                    </div>
                    <span className="hidden lg:block font-semibold whitespace-nowrap">{step.title}</span>
                </button>
                );
            })}
            </div>

            <div className="bg-white rounded-3xl p-6 md:p-12 shadow-xl shadow-slate-200/50 border border-slate-200 min-h-[500px]">
            
            {/* Step 1: Family */}
            {currentStep === 1 && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-3 mb-8 text-xl font-bold">
                    <Users className="text-blue-600" /> Family & Parent Details
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Search Bar - Full Width */}
                    <div className="md:col-span-2 space-y-2 pb-4 border-b border-slate-100">
                    <label className="text-xs font-bold text-slate-500 uppercase">Search Family Phone</label>
                    <input 
                        type="tel" 
                        id="searchPhone" 
                        value={formData.searchPhone} 
                        onChange={handleInputChange} 
                        placeholder="Enter phone to search existing records..." 
                        className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all" 
                    />
                    </div>
                    
                    {/* Relationship Selector */}
                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Relationship</label>
                    <select 
                        id="parentRelation" 
                        value={formData.parentRelation} 
                        onChange={handleInputChange} 
                        className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        <option>Father</option>
                        <option>Mother</option>
                        <option>Guardian</option>
                    </select>
                    </div>

                    {/* Dynamic Name Field */}
                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">{formData.parentRelation} Name</label>
                    <input 
                        type="text" 
                        id="parentName" 
                        value={formData.parentName} 
                        onChange={handleInputChange} 
                        placeholder="Full Name" 
                        className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none" 
                    />
                    </div>

                    {/* Dynamic Email Field */}
                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">{formData.parentRelation} Email</label>
                    <input 
                        type="email" 
                        id="parentEmail" 
                        value={formData.parentEmail} 
                        onChange={handleInputChange} 
                        placeholder="email@example.com" 
                        className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none" 
                    />
                    </div>

                    {/* Dynamic Phone Field */}
                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Phone</label>
                    <input 
                        type="tel" 
                        id="parentPersonalPhone" 
                        value={formData.parentPersonalPhone} 
                        onChange={handleInputChange} 
                        placeholder="Phone Number" 
                        className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none" 
                    />
                    </div>

                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Parent Type</label>
                    <select 
                        id="parentType" 
                        value={formData.parentType} 
                        onChange={handleInputChange} 
                        className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        <option value="Normal">Normal</option>
                        <option value="Teacher">Teacher (15% Discount)</option>
                        <option value="Staff">Staff (10% Discount)</option>
                    </select>
                    </div>

                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Home Address</label>
                    <input 
                        type="text" 
                        id="address" 
                        value={formData.address} 
                        onChange={handleInputChange} 
                        placeholder="Complete Address" 
                        className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none" 
                    />
                    </div>
                </div>
                </div>
            )}

            {/* Step 2-5 Content logic stays consistent */}
            {currentStep === 2 && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-3 mb-8 text-xl font-bold">
                    <GraduationCap className="text-blue-600" /> Student Details
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Student Name</label>
                    <input type="text" id="studentName" value={formData.studentName} onChange={handleInputChange} className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500" />
                    </div>
                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Date of Birth</label>
                    <input type="date" id="dob" value={formData.dob} onChange={handleInputChange} className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500" />
                    </div>
                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Class</label>
                    <select id="studentClass" value={formData.studentClass} onChange={handleInputChange} className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500">
                        <option>Grade 1</option>
                        <option>Grade 2</option>
                        <option>Grade 3</option>
                        <option>Grade 4</option>
                        <option>Grade 5</option>
                        <option>Grade 6</option>
                        <option>Grade 7</option>
                        <option>Grade 8</option>
                    </select>
                    </div>
                    <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Academic Year</label>
                    <input type="text" value="2025-2026" readOnly className="w-full p-4 rounded-xl bg-slate-200 border border-slate-200 outline-none cursor-not-allowed" />
                    </div>
                </div>
                </div>
            )}

            {currentStep === 3 && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-3 mb-8 text-xl font-bold">
                    <Bus className="text-blue-600" /> Transport Selection
                </div>
                <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Select Route</label>
                    <select id="transportRoute" value={formData.transportRoute} onChange={handleInputChange} className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="0">No Transport</option>
                    <option value="1200">Route A - Zirakpur (₹1,200/mo)</option>
                    <option value="1500">Route B - Chandigarh (₹1,500/mo)</option>
                    </select>
                </div>
                </div>
            )}

            {currentStep === 4 && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-3 mb-8 text-xl font-bold">
                    <Receipt className="text-blue-600" /> Fee Structure Preview
                </div>
                <div className="overflow-hidden border border-slate-200 rounded-2xl">
                    <table className="w-full text-left">
                    <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
                        <tr><th className="p-4">Description</th><th className="p-4">Amount (₹)</th></tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        <tr><td className="p-4">Academic Admission Fee</td><td className="p-4 font-semibold">₹{fees.baseFee.toLocaleString()}</td></tr>
                        {fees.discount > 0 && (
                        <tr className="text-red-500 bg-red-50/30 italic"><td className="p-4">Parent Discount ({formData.parentType})</td><td className="p-4 font-semibold">- ₹{fees.discount.toLocaleString()}</td></tr>
                        )}
                        <tr><td className="p-4">Transport</td><td className="p-4 font-semibold">{fees.transport > 0 ? `₹${fees.transport.toLocaleString()}` : 'No Transport'}</td></tr>
                        <tr className="bg-blue-50 text-blue-700 text-xl font-extrabold"><td className="p-4">Estimated Total</td><td className="p-4">₹{fees.total.toLocaleString()}</td></tr>
                    </tbody>
                    </table>
                </div>
                </div>
            )}

            {currentStep === 5 && (
                <div className="animate-in zoom-in-95 duration-500 text-center py-10">
                <div className="flex justify-center mb-6"><div className="w-20 h-20 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center"><ShieldCheck size={48} /></div></div>
                <h2 className="text-2xl font-bold mb-2">Ready to Finalize?</h2>
                <p className="text-slate-500">Registering student <span className="font-bold text-slate-800">{formData.studentName || "New Student"}</span></p>
                <div className="mt-4 p-4 bg-slate-50 rounded-xl inline-block text-sm text-slate-600">
                    A confirmation summary will be sent to <span className="font-bold">{formData.parentEmail || 'the provided email'}</span>.
                </div>
                </div>
            )}

            {/* Footer Actions */}
            <div className="mt-12 flex justify-between items-center border-t border-slate-100 pt-8">
                <button 
                onClick={prevStep} 
                disabled={currentStep === 1} 
                className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all disabled:opacity-30 bg-slate-100 text-slate-600 hover:bg-slate-200"
                >
                <ChevronLeft size={20} /> Back
                </button>
                <button 
                onClick={nextStep} 
                className={`flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-white shadow-lg transition-all active:scale-95 ${
                    currentStep === 5 ? 'bg-emerald-500 hover:bg-emerald-600 shadow-emerald-200' : 'bg-amber-500 hover:bg-amber-600 shadow-amber-200'
                }`}
                >
                {currentStep === 4 ? "Review & Confirm" : currentStep === 5 ? "Finalize Admission" : "Continue"}
                {currentStep < 5 && <ChevronRight size={20} />}
                </button>
            </div>
            </div>
        </div>
        </div>
    </AdminLayout>
  );
};

export default AdmissionForm;