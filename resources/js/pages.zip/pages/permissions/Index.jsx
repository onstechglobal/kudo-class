import { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import AdminLayout from "@/layouts/AdminLayout";
import Stat from "@/components/StatCard";
import CustomButton from "@/components/form/CustomButton";
import AvatarLetter from "@/components/AvatarLetter";
import {
  Search,
  Plus,
  Edit2,
  Trash2,
  Shield,
  ShieldCheck,
  ShieldOff,
} from "lucide-react";

export default function PermissionListing() {
  const [permissions, setPermissions] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  /* ================= LOAD ================= */
  useEffect(() => {
    axios
      .get("/permissions")
      .then(res => setPermissions(res.data))
      .finally(() => setLoading(false));
  }, []);

  /* ================= FILTER ================= */
  const filtered = permissions.filter(p =>
    p.module?.toLowerCase().includes(search.toLowerCase())
  );

  /* ================= STATS ================= */
  const total = permissions.length;
  const active = permissions.filter(p => p.status === "active").length;
  const inactive = total - active;

  /* ================= DELETE ================= */
  function deletePermission(id) {
    if (!confirm("Are you sure you want to delete this permission?")) return;

    axios.delete(`/permissions/${id}`).then(() => {
      setPermissions(prev => prev.filter(p => p.permission_id !== id));
    });
  }

  return (
    <AdminLayout>
      <div className="p-6 bg-gray-50 min-h-screen">

        {/* HEADER */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Permission Directory</h1>
            <p className="text-sm text-gray-500">Manage system permissions</p>
          </div>

          <CustomButton
            text="Add Permission"
            to="/admin/permissions/create"
            Icon={Plus}
            className="bg-[#faae1c] text-white hover:bg-[#faae1c]/85"
          />
        </div>

        {/* STATS */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Stat label="Total Permissions" value={total} icon={<Shield />} />
          <Stat label="Active" value={active} icon={<ShieldCheck />} color="green" />
          <Stat label="Inactive" value={inactive} icon={<ShieldOff />} color="red" />
        </div>

        {/* SEARCH */}
        <div className="bg-white p-4 rounded-xl border border-gray-200 mb-6">
          <div className="relative flex-1 min-w-[300px]">
            <Search className="absolute left-3 top-3 text-gray-400" size={18} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by permission name..."
              className="
                pl-10 w-full py-2 rounded-lg
                border border-gray-200
                focus:outline-none
              "
            />
          </div>
        </div>

        {/* TABLE */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead className="bg-gray-50 text-gray-600 text-xs uppercase font-bold">
              <tr>
                <th className="p-4">Permission</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-center">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y">
              {loading && (
                <tr>
                  <td colSpan="3" className="p-6 text-center text-gray-500">
                    Loading permissions...
                  </td>
                </tr>
              )}

              {!loading &&
                filtered.map(p => (
                  <tr
                    key={p.permission_id}
                    className="hover:bg-gray-50 border-gray-200 "
                  >
                    <td className="p-4 font-bold text-gray-800">
                    <div className="flex items-center gap-3">
                      {p.logo_url ? (
                        <img
                          src={`https://kudoclass.onstech.in/storage/${p.logo_url.replace(
                            "public/",
                            ""
                          )}`}
                          alt={p.module}
                          className="w-10 h-10 rounded-full border border-gray-200 object-cover shadow-sm"
                        />
                      ) : (
                        <AvatarLetter
                          text={p.module}
                          size={40}
                          className="rounded-full"
                        />
                      )}

                      <div>
                        <div className="text-sm font-bold text-gray-800">
                          {p.module}
                        </div>
                      </div>
                    </div>
                  </td>

                    <td className="p-4">
                      <span
                        className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                          p.status === "active"
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>

                    <td className="p-4">
                      <div className="flex justify-center items-center gap-2">
                        <Link
                          to={`/admin/permissions/${p.permission_id}/edit`}
                          className="text-amber-600"
                          title="Edit"
                        >
                          <Edit2 size={16} />
                        </Link>

                        <button
                          onClick={() => deletePermission(p.permission_id)}
                          className="text-red-600 cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

              {!loading && !filtered.length && (
                <tr>
                  <td colSpan="3" className="p-6 text-center text-gray-500">
                    No permissions found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

      </div>
    </AdminLayout>
  );
}
