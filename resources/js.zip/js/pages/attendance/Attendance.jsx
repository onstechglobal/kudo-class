import { useState } from "react";
import AdminLayout from '../../layouts/AdminLayout';
import CustomSelect from '../../components/form/CustomSelect';
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";

export default function Attendance() {
    const [startDate, setStartDate] = useState(new Date());

    const [view, setView] = useState("list");
    const [date, setDate] = useState("2026-01-28");

    const students = [
        { id: 1, roll: "#01", name: "Arjun Sharma", label: "Arjun Sharma", value: 1 },
        { id: 2, roll: "#02", name: "Sarah Jenkins", label: "Sarah Jenkins", value: 2 },
    ];
    
    const [studentSelect, setStudentSelect] = useState(1);

    const [attendance, setAttendance] = useState({
        1: "P",
        2: "P",
    });

  const setStatus = (id, status) => {
    setAttendance({ ...attendance, [id]: status });
  };

  const markAllPresent = () => {
    const updated = {};
    students.forEach(s => (updated[s.id] = "P"));
    setAttendance(updated);
  };

  return (
    <AdminLayout>
        <div className="min-h-screen bg-gray-50 p-6 pb-32">
        {/* HEADER */}
        <div className="flex justify-between items-center mb-6">
            <div>
            <h1 className="text-2xl font-bold text-gray-800">
                {view === "list" ? "Attendance Register" : "Student Insights"}
            </h1>
            <p className="text-gray-500">Class 10-A | Date: {date}</p>
            </div>

            <div className="flex gap-2">
            <button
                onClick={() => setView("list")}
                className={`cursor-pointer px-4 py-2 rounded-md border border-gray-200 font-semibold transition ${
                view === "list"
                    ? "bg-blue-600 text-white"
                    : "bg-white text-gray-600 hover:bg-gray-100"
                }`}
            >
                Marking List
            </button>
            <button
                onClick={() => setView("stats")}
                className={`cursor-pointer px-4 py-2 rounded-md border border-gray-200 font-semibold transition ${
                view === "stats"
                    ? "bg-blue-600 text-white"
                    : "bg-white text-gray-600 hover:bg-gray-100"
                }`}
            >
                Student Analytics
            </button>
            </div>
        </div>

        {/* LIST VIEW */}
        {view === "list" && (
            <>
            {/* DATE + ACTION */}
            <div className="bg-white border border-gray-200 rounded-xl p-4 flex justify-between items-center mb-5">
                <DatePicker selected={startDate} onChange={(date) => setStartDate(date)} className="px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" />
                <button
                onClick={markAllPresent}
                className="cursor-pointer bg-blue-600 text-white px-5 py-2 rounded-md font-semibold hover:bg-blue-700 transition"
                >
                Quick Mark All Present
                </button>
            </div>

            {/* TABLE */}
            <div className="bg-white rounded-xl border border-gray-300 overflow-x-auto">
                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="bg-gray-50 border-b border-gray-200 text-gray-600 text-xs uppercase font-bold">
                            <th className="p-4 text-left">Roll</th>
                            <th className="p-4 text-left">Student</th>
                            <th className="p-4 text-left">Status</th>
                            <th className="p-4 text-left">Remarks</th>
                            <th className="p-4 text-left">Action</th>
                        </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {students.map(s => (
                    <tr key={s.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4"><span className="text-sm font-semibold text-gray-800">{s.roll}</span></td>
                        <td className="px-6 py-4"><span className="text-sm font-bold text-gray-900">{s.name}</span></td>

                        {/* STATUS */}
                        <td className="px-6 py-4">
                            <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
                                {["P", "A", "L"].map(st => (
                                <button
                                    key={st}
                                    onClick={() => setStatus(s.id, st)}
                                    className={`cursor-pointer w-9 h-9 rounded-md font-bold transition ${
                                    attendance[s.id] === st
                                        ? st === "P"
                                        ? "bg-green-500 text-white"
                                        : st === "A"
                                        ? "bg-red-500 text-white"
                                        : "bg-yellow-400 text-white"
                                        : "bg-white text-gray-400 hover:bg-gray-50"
                                    }`}
                                >
                                    {st}
                                </button>
                                ))}
                            </div>
                        </td>

                        {/* REMARKS */}
                        <td className="px-6 py-4">
                        <input
                            placeholder="Note..."
                            className="border border-gray-200 rounded-md px-2 py-1 w-28 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                        </td>

                        {/* ACTION */}
                        <td className="px-6 py-4">
                            <button
                                onClick={() => {
                                    setStudentSelect(s.id)
                                    setView("stats")
                                }}
                                className="cursor-pointer bg-blue-600 text-white px-3 py-1 rounded-md text-xs hover:bg-blue-700 transition"
                            >
                                View History
                            </button>
                        </td>
                    </tr>
                    ))}
                </tbody>
            </table>
            </div>
            </>
        )}

        {/* STATS VIEW */}
        {view === "stats" && (
            <>
            <div className="bg-white border border-gray-200 rounded-xl p-4 mb-6 flex justify-between items-center">
                <div className="w-48">
                    <CustomSelect options={students} value={studentSelect} onChange={setStudentSelect} placeholder="Select Student" />
                </div>
                {/* <select className="cursor-pointer border border-gray-200 rounded-md px-3 py-2 font-semibold focus-visible:outline-none focus:ring-2 focus:ring-blue-500">
                {students.map(s => (
                    <option key={s.id}>
                    {s.roll} - {s.name}
                    </option>
                ))}
                </select> */}
                <span className="font-bold text-blue-600">Overall Grade: A+</span>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-6">
                {[
                ["Attendance Rate", "94%", "text-blue-600"],
                ["Total Present", "124", "text-green-600"],
                ["Total Absent", "8", "text-red-600"],
                ["Late Entry", "3", "text-yellow-500"],
                ].map(([label, val, color]) => (
                <div
                    key={label}
                    className="bg-white border border-gray-200 rounded-lg p-4 text-center"
                >
                    <div className="text-xs text-gray-500 uppercase">{label}</div>
                    <div className={`text-2xl font-bold ${color}`}>{val}</div>
                </div>
                ))}
            </div>

            <div className="grid grid-cols-3 gap-6">
                <div className="col-span-2 bg-white border border-gray-200 rounded-xl p-5">
                <h3 className="font-semibold mb-3">Monthly Presence Trends</h3>
                <div className="h-64 border border-dashed border-gray-200 rounded-md flex items-center justify-center text-gray-400">
                    [ Bar Chart Placeholder ]
                </div>
                </div>

                <div className="bg-white border border-gray-200 rounded-xl p-5">
                <h3 className="font-semibold mb-4">Monthly Heatmap</h3>
                <div className="grid grid-cols-7 gap-1">
                    {Array.from({ length: 14 }).map((_, i) => (
                    <div
                        key={i}
                        className={`aspect-square rounded-md flex items-center justify-center text-xs ${
                        i % 5 === 0
                            ? "bg-red-100 text-red-700"
                            : "bg-green-100 text-green-700"
                        }`}
                    >
                        {i + 1}
                    </div>
                    ))}
                </div>
                </div>
            </div>
            </>
        )}

        {/* FIXED ACTION BAR */}
        {view === "list" && (
            <div className="fixed bottom-0 left-0 right-0 bg-white px-10 py-4 flex justify-end items-center">
                <div className="flex gap-3">
                    <button className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition shadow-sm hover:shadow-xl cursor-pointer border border-gray-200">
                    Discard
                    </button>
                    <button className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition shadow-sm cursor-pointer bg-[#faae1c] text-white hover:bg-[#faae1c]/90">
                    Save Attendance
                    </button>
                </div>
            </div>
        )}
        </div>
    </AdminLayout>
  );
}
