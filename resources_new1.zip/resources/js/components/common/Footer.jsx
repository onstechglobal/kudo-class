export default function Footer() {
    return (
        <footer className="bg-white border-t border-gray-300 px-6 py-3 text-sm text-center text-gray-500">
            © 2026 School Admin Panel
        </footer>
    );
}
