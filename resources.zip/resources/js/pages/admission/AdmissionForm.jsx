import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Users, GraduationCap, Bus, Receipt, CheckCircle, ShieldCheck, ChevronLeft, ChevronRight, MapPin, Calculator, AlertCircle } from 'lucide-react';
import AdminLayout from '../../layouts/AdminLayout';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const AdmissionForm = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [maxReachedStep, setMaxReachedStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  const [classes, setClasses] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [classFees, setClassFees] = useState([]);

  const [formData, setFormData] = useState({
    familyPhone: '',
    address_line1: '',
    address_line2: '',
    city: '',
    district: '',
    state: '',
    pincode: '',
    guardian1Name: '',
    guardian1Phone: '',
    guardian1Email: '',
    guardian1Relation: 'Father',
    guardian2Name: '',
    guardian2Phone: '',
    guardian2Relation: 'Mother',
    parentEmail: '',
    parentType: 'Normal',
    studentName: '',
    lastName: '',
    dob: '',
    studentClass: '',
    policy_id: '',
    bloodGroup: '',
    transportRoute: '0',
  });

  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const storedUser = localStorage.getItem("user");
        if (storedUser) {
          const user = JSON.parse(storedUser);
          const [classRes, policyRes] = await Promise.all([
            axios.get(`api/get-classes`, { params: { school_id: user.school_id } }),
            axios.get(`api/get-fee-policies`, { params: { school_id: user.school_id } })
          ]);
          setClasses(Array.isArray(classRes.data.data) ? classRes.data.data.map(c => ({ label: c.class_name, value: c.class_id })) : []);
          setPolicies(policyRes.data.data || []);
        }
      } catch (err) {
        console.error("Error fetching data:", err);
      } finally {
      }
    };
    fetchInitialData();
  }, []);

  useEffect(() => {
    if (formData.studentClass) {
      axios.get(`api/get-class-fees`, { params: { class_id: formData.studentClass } })
        .then(res => setClassFees(res.data.data || []))
        .catch(err => console.error("Error fetching class fees:", err));
    }
  }, [formData.studentClass]);

  const steps = [
    { id: 1, title: 'Family & Guardians', icon: Users },
    { id: 2, title: 'Student & Fees', icon: GraduationCap },
    { id: 3, title: 'Transport', icon: Bus },
    { id: 4, title: 'Preview', icon: Receipt },
    { id: 5, title: 'Confirm', icon: CheckCircle },
  ];

  const calculateFees = () => {
    const academicBase = classFees.reduce((acc, curr) => acc + parseFloat(curr.amount), 0);
    const transport = parseFloat(formData.transportRoute) || 0;
    let discount = 0;
    if (formData.parentType === "Teacher") discount = academicBase * 0.15;
    else if (formData.parentType === "Staff") discount = academicBase * 0.10;
    return { academicBase, discount, transport, total: academicBase - discount + transport };
  };

  const fees = calculateFees();

  const validateStep = (step) => {
    let newErrors = {};
    const phoneRegex = /^[0-9]{10}$/;
    if (step === 1) {
      if (!phoneRegex.test(formData.familyPhone)) newErrors.familyPhone = "10-digit number required";
      if (!formData.guardian1Name) newErrors.guardian1Name = "Name required";
      if (!phoneRegex.test(formData.guardian1Phone)) newErrors.guardian1Phone = "10-digit number required";
      if (!formData.guardian1Email) newErrors.guardian1Email = "Email Address is required";
    }
    if (step === 2) {
      if (!formData.studentName) newErrors.studentName = "Name required";
      if (!formData.studentClass) newErrors.studentClass = "Select a class";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
    if (errors[id]) setErrors(prev => ({ ...prev, [id]: null }));
  };

  const nextStep = async () => {
    if (!validateStep(currentStep)) return;
    if (currentStep < 5) {
      const next = currentStep + 1;
      setCurrentStep(next);
      if (next > maxReachedStep) setMaxReachedStep(next);
    } else {
      try {
        setIsSubmitting(true);
        const user = JSON.parse(localStorage.getItem("user"));
        const response = await axios.post(`api/admissions`, {
          ...formData,
          school_id: user.school_id,
          fee_summary: fees,
          fee_details: classFees
        });
        if (response.data.success) {
          alert("Success! Admission complete.");
          window.location.reload();
        }
      } catch (err) {
        alert("Submission failed.");
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const ErrorLabel = ({ id }) => errors[id] ? <span className="text-[10px] text-red-500 font-bold lowercase ml-1">({errors[id]})</span> : null;

  return (
    <AdminLayout>
      <div className="min-h-screen bg-slate-50 p-4 md:p-8 text-slate-800 font-sans">
        <div className="max-w-4xl mx-auto">

          <div className="mb-8">
            <p className="text-xs font-bold text-blue-600 tracking-widest uppercase mb-1">Admissions / 2026-27</p>
            <h1 className="text-3xl font-bold">Student Enrollment</h1>
          </div>

          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex justify-between mb-8 overflow-x-auto gap-4 scrollbar-hide">
            {steps.map((step) => {
              const Icon = step.icon;
              const isActive = currentStep === step.id;
              const isVisited = step.id <= maxReachedStep;
              return (
                <button
                  key={step.id}
                  onClick={() => isVisited && setCurrentStep(step.id)}
                  disabled={!isVisited}
                  className={`flex items-center gap-3 transition-all flex-shrink-0 cursor-pointer disabled:cursor-not-allowed ${isActive ? 'text-blue-600' : isVisited ? 'text-emerald-500' : 'text-slate-400 opacity-50'}`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive ? 'bg-blue-600 text-white' : step.id < currentStep ? 'bg-emerald-500 text-white' : 'bg-slate-100'}`}>
                    <Icon size={18} />
                  </div>
                  <span className="hidden lg:block font-semibold text-sm">{step.title}</span>
                </button>
              );
            })}
          </div>

          <div className="bg-white rounded-3xl p-6 md:p-10 shadow-xl shadow-slate-200/50 border border-slate-200 min-h-[550px]">
            {/* STEP 1: FAMILY & GUARDIANS */}
            {currentStep === 1 && (
              <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4">
                <section>
                  <div className="flex items-center gap-2 mb-6 pb-2 border-b border-slate-100">
                    <MapPin size={20} className="text-blue-600" />
                    <h2 className="text-lg font-bold">1. Family & Address</h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase">Family Phone <ErrorLabel id="familyPhone" /></label>
                      <input type="text" id="familyPhone" value={formData.familyPhone} onChange={handleInputChange} className="w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer" placeholder="Primary Contact" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase">Address Line 1 <ErrorLabel id="address_line1" /></label>
                      <input type="text" id="address_line1" value={formData.address_line1} onChange={handleInputChange} className="w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer" placeholder="House No / Street" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase">City <ErrorLabel id="city" /></label>
                      <input type="text" id="city" value={formData.city} onChange={handleInputChange} className="w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase">Pincode <ErrorLabel id="pincode" /></label>
                      <input type="text" id="pincode" value={formData.pincode} onChange={handleInputChange} className="w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer" />
                    </div>
                  </div>
                </section>

                <section>
                  <div className="flex items-center gap-2 mb-6 pb-2 border-b border-slate-100">
                    <ShieldCheck size={20} className="text-blue-600" />
                    <h2 className="text-lg font-bold">2. Guardian Details</h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-black text-slate-500 uppercase">Guardian 1 *</label>
                        <input type="text" id="guardian1Relation" value={formData.guardian1Relation} onChange={handleInputChange} className="text-[10px] bg-white border px-2 py-0.5 rounded cursor-pointer" placeholder="Relation" />
                      </div>
                      <input type="text" id="guardian1Name" placeholder="Full Name" value={formData.guardian1Name} onChange={handleInputChange} className="w-full p-2.5 bg-white border border-slate-200 rounded-lg text-sm cursor-pointer" />
                      <ErrorLabel id="guardian1Name" />
                      <input type="tel" id="guardian1Phone" placeholder="Phone" value={formData.guardian1Phone} onChange={handleInputChange} className="w-full p-2.5 bg-white border border-slate-200 rounded-lg text-sm cursor-pointer" />
                      <ErrorLabel id="guardian1Phone" />

                      {/* Added Email Field */}
                      <input type="email" id="guardian1Email" placeholder="Email Address" value={formData.guardian1Email} onChange={handleInputChange} className="w-full p-2.5 bg-white border border-slate-200 rounded-lg text-sm cursor-pointer" />
                      <ErrorLabel id="guardian1Email" />
                    </div>

                    <div className="space-y-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-black text-slate-500 uppercase">Guardian 2</label>
                        <input type="text" id="guardian2Relation" value={formData.guardian2Relation} onChange={handleInputChange} className="text-[10px] bg-white border px-2 py-0.5 rounded cursor-pointer" placeholder="Relation" />
                      </div>
                      <input type="text" id="guardian2Name" placeholder="Full Name" value={formData.guardian2Name} onChange={handleInputChange} className="w-full p-2.5 bg-white border border-slate-200 rounded-lg text-sm cursor-pointer" />
                      <input type="tel" id="guardian2Phone" placeholder="Phone" value={formData.guardian2Phone} onChange={handleInputChange} className="w-full p-2.5 bg-white border border-slate-200 rounded-lg text-sm cursor-pointer" />
                    </div>
                  </div>
                </section>
              </div>
            )}

            {/* STEP 2: STUDENT & FEES (RE-ADDED FEE BREAKDOWN) */}
            {currentStep === 2 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
                <div className="flex items-center gap-3 mb-6 text-xl font-bold border-b border-slate-100 pb-4">
                  <GraduationCap className="text-blue-600" /> Student Profile & Fees
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Student Name <ErrorLabel id="studentName" /></label>
                    <input type="text" id="studentName" value={formData.studentName} onChange={handleInputChange} className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer" />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">
                      Date of Birth <ErrorLabel id="dob" />
                    </label>
                    <div className="relative w-full">
                      <DatePicker
                        selected={formData.dob ? new Date(formData.dob) : null}
                        onChange={(date) => {
                          handleInputChange({
                            target: { id: "dob", value: date ? date.toISOString().split('T')[0] : "" }
                          });
                        }}
                        dateFormat="yyyy-MM-dd"
                        placeholderText="Select Date"
                        maxDate={new Date()}
                        showMonthDropdown
                        showYearDropdown
                        dropdownMode="select"
                        wrapperClassName="w-full"
                        className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Admission Class</label>
                    <select id="studentClass" value={formData.studentClass} onChange={handleInputChange} className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer">
                      <option value="">Select Class</option>
                      {classes.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Fee Policy</label>
                    <select id="policy_id" value={formData.policy_id} onChange={handleInputChange} className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer">
                      <option value="">Select Policy</option>
                      {policies.map(p => <option key={p.policy_id} value={p.policy_id}>{p.policy_name}</option>)}
                    </select>
                  </div>

                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-500 uppercase">Fee Category</label>
                    <select id="parentType" value={formData.parentType} onChange={handleInputChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none cursor-pointer">
                      <option value="Normal">General</option>
                      <option value="Teacher">Teacher (15% Disc)</option>
                      <option value="Staff">Staff (10% Disc)</option>
                    </select>
                  </div>

                </div>

                {/* THE FEE TABLE YOU WANTED BACK */}
                {classFees.length > 0 && (
                  <div className="mt-6 p-6 bg-blue-50/50 rounded-2xl border border-blue-100">
                    <div className="flex items-center gap-2 mb-4 text-blue-700 font-bold"><Calculator size={18} /> Applicable Fees for Class</div>
                    <div className="space-y-3">
                      {classFees.map((fee, idx) => (
                        <div key={idx} className="flex justify-between items-center text-sm border-b border-blue-100 pb-2">
                          <span className="text-slate-600 font-medium">{fee.fee_name} <span className="text-[10px] bg-white px-1 rounded border capitalize">{fee.frequency}</span></span>
                          <span className="font-bold text-slate-800">₹{parseFloat(fee.amount).toLocaleString()}</span>
                        </div>
                      ))}
                      <div className="flex justify-between pt-2 text-blue-800 font-black">
                        <span>Total Academic Fee</span>
                        <span>₹{fees.academicBase.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* STEP 3: TRANSPORT */}
            {currentStep === 3 && (
              <div className="animate-in fade-in slide-in-from-bottom-4 space-y-6">
                <div className="flex items-center gap-3 mb-8 text-xl font-bold"><Bus className="text-blue-600" /> Transport Services</div>
                <div className="max-w-md space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Select Route</label>
                    <select id="transportRoute" value={formData.transportRoute} onChange={handleInputChange} className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 outline-none font-medium focus:ring-2 focus:ring-blue-500 cursor-pointer">
                      <option value="0">No Transport</option>
                      <option value="1000">Test Route - ₹1,000</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 4: PREVIEW (ADDED FULL BREAKDOWN HERE TOO) */}
            {currentStep === 4 && (
              <div className="space-y-8 animate-in fade-in">
                <div className="flex items-center gap-3 text-xl font-bold"><Receipt className="text-blue-600" /> Final Summary Preview</div>
                <div className="bg-slate-50 rounded-3xl p-8 border border-slate-100 space-y-6">
                  <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                    <p><span className="text-slate-400 font-bold uppercase text-[10px]">Student:</span><br />{formData.studentName}</p>
                    <p><span className="text-slate-400 font-bold uppercase text-[10px]">Class:</span><br />{classes.find(c => c.value == formData.studentClass)?.label || 'N/A'}</p>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-slate-200">
                    <div className="flex justify-between"><span>Base Academic Fees</span><span className="font-bold">₹{fees.academicBase.toLocaleString()}</span></div>
                    {fees.discount > 0 && <div className="flex justify-between text-emerald-600 italic"><span>({formData.parentType}) Discount</span><span>- ₹{fees.discount.toLocaleString()}</span></div>}
                    <div className="flex justify-between"><span>Transport Fee</span><span className="font-bold">₹{fees.transport.toLocaleString()}</span></div>
                    <div className="flex justify-between text-xl font-black text-blue-600 pt-4 border-t border-dashed">
                      <span>Net Total</span>
                      <span>₹{fees.total.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 5: FINAL VERIFICATION */}
            {currentStep === 5 && (
              <div className="flex flex-col items-center justify-center py-12 space-y-8 animate-in zoom-in-95">
                <div className="w-20 h-20 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center">
                  <AlertCircle size={40} />
                </div>
                <div className="text-center space-y-3">
                  <h2 className="text-3xl font-black text-slate-800">Are you sure?</h2>
                  <p className="text-slate-500 max-w-md mx-auto">
                    Please check all the details for <b>{formData.studentName}</b> before finalizing. Once confirmed, the student will be enrolled and a fee ledger will be created.
                  </p>
                </div>
              </div>
            )}

            {/* Footer Buttons */}
            <div className="mt-12 flex justify-between items-center border-t border-slate-100 pt-8">
              <button
                onClick={() => setCurrentStep(prev => prev - 1)}
                disabled={currentStep === 1 || isSubmitting}
                className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all disabled:opacity-0 bg-slate-100 text-slate-600 hover:bg-slate-200 cursor-pointer"
              >
                <ChevronLeft size={20} /> Back
              </button>
              <button
                onClick={nextStep}
                disabled={isSubmitting}
                className={`flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-white shadow-lg transition-all active:scale-95 cursor-pointer ${currentStep === 5 ? 'bg-emerald-500' : 'bg-[#faae1c]'}`}
              >
                {isSubmitting ? "Submitting..." : currentStep === 5 ? "Confirm & Submit" : "Continue"}
                {!isSubmitting && currentStep < 5 && <ChevronRight size={20} />}
                {!isSubmitting && currentStep === 5 && <CheckCircle size={20} />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdmissionForm;