import AdminLayout from "../../layouts/AdminLayout";
import PageHeader from "../../components/common/PageHeader";
import Input from "../../components/form/Input";
import CustomSelect from "../../components/form/CustomSelect";
import api from "../../helpers/api";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Settings, Save, Loader2, AlertCircle } from "lucide-react";

const CreateFeePolicy = () => {

    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const [formData, setFormData] = useState({
        policy_name: "",
        grace_days: "",
        partial_payment: 1,
        late_reminder: 1,
        status: "active",
    });

    const yesNoOptions = [
        { label: "Yes", value: 1 },
        { label: "No", value: 0 },
    ];

    const statusOptions = [
        { label: "Active", value: "active" },
        { label: "Inactive", value: "inactive" },
    ];

    const handleChange = (name, value) => {
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError("");

        try {

            if (!formData.policy_name)
                throw new Error("Policy name is required");

            if (!formData.grace_days || parseInt(formData.grace_days) < 0)
                throw new Error("Valid grace days required");

            const user = JSON.parse(localStorage.getItem("user"));
            let schoolId = user?.school_id;
            if (!schoolId || schoolId === 0) schoolId = 1;

            const payload = {
                ...formData,
                school_id: schoolId,
                grace_days: parseInt(formData.grace_days),
            };

            const response = await api.post("/api/fees-policy", payload);

            if (response.data.success) {
                navigate("/fee-policies", {
                    state: {
                        message: "Fee policy created successfully!",
                        status: "success"
                    }
                });
            } else {
                throw new Error(response.data.message);
            }

        } catch (err) {
            setError(err.response?.data?.message || err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <AdminLayout>
            <div className="bg-[#F8FAFC] min-h-screen p-6">
                <form onSubmit={handleSubmit}>

                    {/* Header */}
                    <div className="bg-white border-b border-gray-200 px-8 py-5">
                        <div className="flex justify-between">
                            <PageHeader
                                prevRoute="/fee-policies"
                                breadcrumbParent="Fee Policies"
                                breadcrumbCurrent="Add"
                                title="Create Fee Policy"
                            />
                            <button
                                type="submit"
                                disabled={loading}
                                className="flex items-center gap-2 bg-[#faae1c] text-white px-7 py-2.5 rounded-xl font-bold text-sm shadow-lg cursor-pointer"
                            >
                                {loading
                                    ? <Loader2 className="animate-spin" size={18} />
                                    : <Save size={18} />}
                                Save
                            </button>
                        </div>
                    </div>

                    {/* Body */}
                    <div className="p-8 max-w-[1200px] mx-auto">

                        {error && (
                            <div className="p-4 bg-red-50 text-red-700 rounded-xl mt-4 flex gap-2">
                                <AlertCircle size={18} />
                                {error}
                            </div>
                        )}

                        <div className="bg-white rounded-[2.5rem] p-10 border border-gray-200 shadow-sm space-y-8">

                            <h2 className="text-xl font-black flex items-center gap-2">
                                <Settings className="text-blue-600" size={24} />
                                Policy Configuration
                            </h2>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                                <Input
                                    label="Policy Name"
                                    value={formData.policy_name}
                                    onChange={e => handleChange("policy_name", e.target.value)}
                                />

                                <Input
                                    label="Grace Days"
                                    type="number"
                                    value={formData.grace_days}
                                    onChange={e => handleChange("grace_days", e.target.value)}
                                />

                                <CustomSelect
                                    label="Allow Partial Payment"
                                    options={yesNoOptions}
                                    value={formData.partial_payment}
                                    onChange={value => handleChange("partial_payment", value)}
                                />

                                <CustomSelect
                                    label="Enable Late Reminder"
                                    options={yesNoOptions}
                                    value={formData.late_reminder}
                                    onChange={value => handleChange("late_reminder", value)}
                                />

                                <CustomSelect
                                    label="Status"
                                    options={statusOptions}
                                    value={formData.status}
                                    onChange={value => handleChange("status", value)}
                                />

                            </div>

                        </div>
                    </div>

                </form>
            </div>
        </AdminLayout>
    );
};

export default CreateFeePolicy;
