import React, { useState } from 'react';
import AdminLayout from '../../layouts/AdminLayout';
import { useNavigate } from 'react-router-dom';
import { 
    UserPlus, ArrowLeft, Save, Shield, 
    Mail, Phone, Lock, School, UserCircle 
} from 'lucide-react';
import CustomButton from '../../components/form/CustomButton';
import Input from '../../components/form/Input';
import CustomSelect from '../../components/form/CustomSelect';

const EditStaff = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);

    // Form State
    const [formData, setFormData] = useState({
        name: '',
        role: '',
        email: '',
        mobile: '',
        school_id: '',
        password: '',
        status: 'active'
    });

    const roleOptions = [
        { label: "Administrator", value: "Administrator" },
        { label: "Accountant", value: "Accountant" },
        { label: "Receptionist", value: "Receptionist" },
        { label: "Librarian", value: "Librarian" },
    ];

    const schoolOptions = [
        { label: "Greenwood High School", value: "1" },
        { label: "Oakridge International", value: "2" },
        { label: "St. Mary's Academy", value: "3" },
    ];

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);
        // Simulate API Call
        console.log("Submitting Staff Data:", formData);
        setTimeout(() => {
            setLoading(false);
            navigate('/staff-directory'); // Redirect to listing after success
        }, 1500);
    };

    return (
        <AdminLayout>
            <div className="p-6 bg-gray-50 min-h-screen font-sans">
                
                {/* --- BREADCRUMB / HEADER --- */}
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
                    <div className="flex items-center gap-4">
                        <button 
                            onClick={() => navigate(-1)}
                            className="p-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-100 transition-colors"
                        >
                            <ArrowLeft size={20} className="text-gray-600" />
                        </button>
                        <div>
                            <h1 className="text-2xl font-bold text-gray-800">Edit Staff Member</h1>
                            <p className="text-sm text-gray-500">Create a new administrative or support profile</p>
                        </div>
                    </div>
                </div>

                
            </div>
        </AdminLayout>
    );
};

export default EditStaff;