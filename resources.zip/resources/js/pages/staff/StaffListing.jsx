import React, { useState } from 'react';
import AdminLayout from '../../layouts/AdminLayout';
import { Link } from "react-router-dom";
import {
    Search, Filter, Pencil, Trash2, UserCheck, Users, UserMinus,
    ShieldCheck, Mail, Phone, SlidersHorizontal
} from 'lucide-react';
import CustomButton from '../../components/form/CustomButton';
import DeleteConfirmModal from '../../components/common/DeleteConfirmModal';
import CustomSelect from '../../components/form/CustomSelect';
import AvatarLetter from '../../components/AvatarLetter';
import Stat from '../../components/StatCard';
import FilterDrawer from '../../components/common/FilterDrawer';

const StaffListing = () => {
    // Static Data matching tb_staff structure
    const static_staff = [
        { staff_id: 1, name: "John Doe", role: "Administrator", email: "john@school.com", mobile: "9876543210", status: "active", school_name: "Greenwood High" },
        { staff_id: 2, name: "Sarah Smith", role: "Accountant", email: "sarah@school.com", mobile: "9876543211", status: "active", school_name: "Greenwood High" },
        { staff_id: 3, name: "Michael Ross", role: "Receptionist", email: "michael@school.com", mobile: "9876543212", status: "inactive", school_name: "Oakridge Intl" },
    ];

    const [loading, setLoading] = useState(false);
    const [isFilterOpen, setIsFilterOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [roleFilter, setRoleFilter] = useState('');
    const [statusFilter, setStatusFilter] = useState('');

    const roleOptions = [
        { label: "Role (All)", value: "" },
        { label: "Admin", value: "Administrator" },
        { label: "Accountant", value: "Accountant" },
        { label: "Receptionist", value: "Receptionist" },
    ];

    const statusOptions = [
        { label: "Status (All)", value: "" },
        { label: "Active", value: "active" },
        { label: "Inactive", value: "inactive" },
    ];

    // Modal States
    const [open, setOpen] = useState(false);
    const [selectedStaff, setSelectedStaff] = useState(null);

    const handleOpenModal = (staff) => {
        setSelectedStaff(staff);
        setOpen(true);
    };

    const scrambleId = (id) => btoa(`st_${id.toString(16)}`).replace(/=/g, '');

    return (
        <AdminLayout>
            <DeleteConfirmModal
                isOpen={open}
                title="Remove Staff Member"
                schoolName={selectedStaff ? selectedStaff.name : ""}
                onClose={() => setOpen(false)}
                onDelete={() => setOpen(false)}
            />

            {/* Reusable Filter Drawer */}
            <FilterDrawer
                isOpen={isFilterOpen}
                onClose={() => setIsFilterOpen(false)}
                onApply={() => setIsFilterOpen(false)}
                onReset={() => { setRoleFilter(''); setStatusFilter(''); }}
            >
                <div className="space-y-4">
                    <div>
                        <label className="text-sm font-semibold text-gray-700">Staff Role</label>
                        <CustomSelect options={roleOptions} value={roleFilter} onChange={setRoleFilter} />
                    </div>
                    <div>
                        <label className="text-sm font-semibold text-gray-700">Employment Status</label>
                        <CustomSelect options={statusOptions} value={statusFilter} onChange={setStatusFilter} />
                    </div>
                </div>
            </FilterDrawer>

            <div className="p-6 bg-gray-50 min-h-screen font-sans">
                {/* PAGE HEADER */}
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-800">Staff Directory</h1>
                        <p className="text-sm text-gray-500">Manage non-teaching staff and administrative roles</p>
                    </div>
                    <CustomButton
                        text="Add Staff Member"
                        to="/staff/add"
                        className="bg-[#faae1c] text-white hover:bg-[#faae1c]/85"
                    />
                </div>

                {/* STATS CARDS */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <Stat label="Total Staff" value={static_staff.length} icon={<Users />} />
                    <Stat label="Active Duty" value="2" icon={<UserCheck />} color="green" />
                    <Stat label="On Leave" value="1" icon={<UserMinus />} color="red" />
                </div>

                {/* FILTERS SECTION */}
                <div className="bg-white p-4 rounded-xl border border-gray-200 mb-6 flex flex-wrap gap-4 items-center justify-between">
                    <div className="flex-1 min-w-[300px]">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                            <input
                                type="text"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                placeholder="Search by name, email or mobile..."
                                className="w-full pl-10 pr-12 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                            />
                        </div>
                    </div>
                    <div className="flex gap-3">
                        <div className="w-44">
                            <CustomSelect options={roleOptions} value={roleFilter} onChange={setRoleFilter} placeholder="All Roles" />
                        </div>
                        <button
                            onClick={() => setIsFilterOpen(true)}
                            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
                        >
                            <SlidersHorizontal size={16} /> More Filters
                        </button>
                    </div>
                </div>

                {/* DATA TABLE */}
                <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-gray-50 border-b border-gray-200 text-gray-600 text-xs uppercase font-bold">
                                    <th className="px-6 py-4">Staff Member</th>
                                    <th className="px-6 py-4">Role</th>
                                    <th className="px-6 py-4">Contact</th>
                                    <th className="px-6 py-4">School</th>
                                    <th className="px-6 py-4">Status</th>
                                    <th className="px-6 py-4 text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {static_staff.map((staff) => (
                                    <tr key={staff.staff_id} className="hover:bg-gray-50 transition-colors">
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-3">
                                                <AvatarLetter text={staff.name} size={40} />
                                                <div className="text-sm font-bold text-gray-800">{staff.name}</div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-1.5 text-sm text-gray-600">
                                                <ShieldCheck size={14} className="text-blue-500" />
                                                {staff.role}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex flex-col gap-1">
                                                <div className="flex items-center gap-2 text-xs text-gray-500">
                                                    {staff.email}
                                                </div>
                                                <div className="flex items-center gap-2 text-xs text-gray-500">
                                                    {staff.mobile}
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-sm text-gray-600">{staff.school_name}</td>
                                        <td className="px-6 py-4">
                                            <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${staff.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                                                }`}>
                                                {staff.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex justify-center items-center gap-3">
                                                <Link to={`/staff/edit/${scrambleId(staff.staff_id)}`} className="text-amber-600 hover:text-amber-800">
                                                    <Pencil size={16} />
                                                </Link>
                                                <button
                                                    onClick={() => handleOpenModal(staff)}
                                                    className="text-red-600 hover:text-red-800 cursor-pointer"
                                                >
                                                    <Trash2 size={16} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    {/* PAGINATION (Static Mockup) */}
                    <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
                        <span className="text-sm text-gray-500">Showing 1 to 3 of 3 records</span>
                        <div className="flex gap-2">
                            <button className="px-3 py-1 border rounded text-sm bg-gray-100 text-gray-400 cursor-not-allowed">Prev</button>
                            <button className="px-3 py-1 border rounded text-sm bg-gray-100 text-gray-400 cursor-not-allowed">Next</button>
                        </div>
                    </div>
                </div>
            </div>
        </AdminLayout>
    );
};

export default StaffListing;