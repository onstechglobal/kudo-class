import AdminLayout from "../../layouts/AdminLayout";
import PageHeader from "../../components/common/PageHeader";
import Input from "../../components/form/Input";
import CustomSelect from "../../components/form/CustomSelect";
import api from "../../helpers/api";
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ShieldAlert, Save, Loader2, AlertCircle, Check } from "lucide-react";

const EditPenalty = () => {
    const { id } = useParams();
    const navigate = useNavigate();

    const [loading, setLoading] = useState(false);
    const [fetching, setFetching] = useState(true);
    const [error, setError] = useState("");

    const [formData, setFormData] = useState({
        fee_type: "",
        penalty_type: "flat",
        penalty_value: "",
        applies_after_days: "",
        frequency: "once",
        is_active: 1
    });

    /* ---------------- OPTIONS (SAME AS CREATE) ---------------- */

    const feeTypeOptions = [
        { label: "Academic", value: "academic" },
        { label: "Transport", value: "transport" },
        { label: "Exam", value: "exam" },
        { label: "All Fees", value: "all" },
    ];

    const penaltyTypeOptions = [
        { label: "Flat Amount", value: "flat" },
        { label: "Percentage (%)", value: "percentage" },
    ];

    const frequencyOptions = [
        { label: "Once", value: "once" },
        { label: "Per Month", value: "per_month" },
    ];

    const statusOptions = [
        { label: "Active", value: 1 },
        { label: "Inactive", value: 0 },
    ];

    /* ---------------- FETCH RULE ---------------- */

    useEffect(() => {
        const fetchRule = async () => {
            try {
                const res = await api.get(`/api/penalty-rules/${id}`);

                if (res.data.status) {
                    const data = res.data.data;

                    setFormData({
                        fee_type: data.fee_type || "",
                        penalty_type: data.penalty_type || "flat",
                        penalty_value: data.penalty_value || "",
                        applies_after_days: data.applies_after_days || "",
                        frequency: data.frequency || "once",
                        is_active: data.is_active ?? 1
                    });
                }
            } catch (err) {
                setError("Failed to load rule");
            } finally {
                setFetching(false);
            }
        };

        fetchRule();
    }, [id]);

    const handleChange = (name, value) => {
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    /* ---------------- UPDATE ---------------- */

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError("");

        try {
            const user = JSON.parse(localStorage.getItem("user"));
            let schoolId = user?.school_id;

            if (!schoolId || schoolId === 0) {
                schoolId = 1;
            }

            const payload = {
                ...formData,
                school_id: schoolId,
                penalty_value: parseFloat(formData.penalty_value),
                applies_after_days: parseInt(formData.applies_after_days),
            };

            const response = await api.put(`/api/penalty-rules/${id}`, payload);

            if (response.data.status) {
                navigate("/penalty-rules", {
                    state: {
                        message: "Penalty rule updated successfully!",
                        status: "success"
                    }
                });
            } else {
                throw new Error(response.data.message);
            }

        } catch (err) {
            setError(err.response?.data?.message || "Update failed");
        } finally {
            setLoading(false);
        }
    };

    if (fetching) {
        return (
            <AdminLayout>
                <div className="flex justify-center items-center h-screen">
                    <Loader2 className="animate-spin text-blue-500" />
                </div>
            </AdminLayout>
        );
    }

    return (
        <AdminLayout>
            <div className="bg-[#F8FAFC] min-h-screen p-6">
                <form onSubmit={handleSubmit}>

                    <div className="bg-white border-b border-gray-200 px-8 py-5 flex justify-between">
                        <PageHeader
                            prevRoute="/penalty-rules"
                            breadcrumbParent="Penalty Rules"
                            breadcrumbCurrent="Edit"
                            title="Edit Penalty Rule"
                        />
                        <button
                            type="submit"
                            disabled={loading}
                            className="flex items-center gap-2 bg-[#faae1c] text-white px-7 py-2.5 rounded-xl"
                        >
                            {loading ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                            Update
                        </button>
                    </div>

                    <div className="p-8 max-w-[1200px] mx-auto">
                        {error && (
                            <div className="p-4 bg-red-50 text-red-700 rounded-xl mt-4 flex gap-2">
                                <AlertCircle size={18} />
                                {error}
                            </div>
                        )}

                        <div className="bg-white rounded-[2.5rem] p-10 border border-gray-200 shadow-sm space-y-8">

                            <h2 className="text-xl font-black flex items-center gap-2">
                                <ShieldAlert className="text-blue-600" size={24} />
                                Penalty Configuration
                            </h2>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                                {/* Fee Type */}
                                <CustomSelect
                                    label="Fee Type"
                                    options={feeTypeOptions}
                                    value={formData.fee_type}
                                    onChange={value => handleChange("fee_type", value)}
                                />

                                {/* Penalty Type */}
                                <CustomSelect
                                    label="Penalty Type"
                                    options={penaltyTypeOptions}
                                    value={formData.penalty_type}
                                    onChange={value => handleChange("penalty_type", value)}
                                />

                                {/* Penalty Value */}
                                <Input
                                    label="Penalty Value"
                                    type="number"
                                    value={formData.penalty_value}
                                    onChange={e => handleChange("penalty_value", e.target.value)}
                                />

                                {/* Applies After */}
                                <Input
                                    label="Applies After Days"
                                    type="number"
                                    value={formData.applies_after_days}
                                    onChange={e => handleChange("applies_after_days", e.target.value)}
                                />

                                {/* Frequency */}
                                <CustomSelect
                                    label="Frequency"
                                    options={frequencyOptions}
                                    value={formData.frequency}
                                    onChange={value => handleChange("frequency", value)}
                                />

                                {/* Status */}
                                <CustomSelect
                                    label="Status"
                                    options={statusOptions}
                                    value={formData.is_active}
                                    onChange={value => handleChange("is_active", value)}
                                />

                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </AdminLayout>
    );
};

export default EditPenalty;
