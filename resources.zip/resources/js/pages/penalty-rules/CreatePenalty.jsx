import AdminLayout from "../../layouts/AdminLayout";
import PageHeader from "../../components/common/PageHeader";
import Input from "../../components/form/Input";
import CustomSelect from "../../components/form/CustomSelect";
import api from "../../helpers/api";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ShieldAlert, Save, Loader2, AlertCircle, Check } from "lucide-react";

const CreatePenalty = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const [formData, setFormData] = useState({
        fee_type: "academic",
        penalty_type: "flat",
        penalty_value: "",
        applies_after_days: "",
        frequency: "per_month",
        is_active: 1,
    });

    const feeTypeOptions = [
        { label: "Academic", value: "academic" },
        { label: "Transport", value: "transport" },
        { label: "Exam", value: "exam" },
        { label: "All Fees", value: "all" },
    ];

    const penaltyTypeOptions = [
        { label: "Flat Amount", value: "flat" },
        { label: "Percentage (%)", value: "percentage" },
    ];

    const frequencyOptions = [
        { label: "Once", value: "once" },
        { label: "Per Month", value: "per_month" },
    ];

    const statusOptions = [
        { label: "Active", value: 1 },
        { label: "Inactive", value: 0 },
    ];

    const handleChange = (name, value) => {
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError("");

        try {
            if (!formData.penalty_value || parseFloat(formData.penalty_value) <= 0)
                throw new Error("Valid penalty value is required");

            if (!formData.applies_after_days || parseInt(formData.applies_after_days) <= 0)
                throw new Error("Applies after days is required");

            const user = JSON.parse(localStorage.getItem("user"));
            let schoolId = user?.school_id;

            // if school_id = 0 → send 1
            if (!schoolId || schoolId === 0) {
                schoolId = 1;
            }

            const payload = {
                ...formData,
                school_id: schoolId,
                penalty_value: parseFloat(formData.penalty_value),
                applies_after_days: parseInt(formData.applies_after_days),
            };

            const response = await api.post("/api/penalty-rules", payload);

            if(response.data.status){
                navigate("/penalty-rules", {
                    state: {
                        message: "Penalty rule created successfully!",
                        status: "success"
                    }
                });
            }else{
                throw new Error(response.data.message);
            }

        } catch (err) {
            setError(err.response?.data?.message || err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <AdminLayout>
            <div className="bg-[#F8FAFC] min-h-screen p-6">
                <form onSubmit={handleSubmit}>

                    <div className="bg-white border-b border-gray-200 px-8 py-5">
                        <div className="flex justify-between">
                            <PageHeader
                                prevRoute="/penalty-rules"
                                breadcrumbParent="Penalty Rules"
                                breadcrumbCurrent="Add"
                                title="Create Penalty Rule"
                            />
                            <button
                                type="submit"
                                disabled={loading}
                                className="flex items-center gap-2 bg-[#faae1c] text-white px-7 py-2.5 rounded-xl font-bold text-sm shadow-lg cursor-pointer"
                            >
                                {loading ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                                Save
                            </button>
                        </div>
                    </div>

                    <div className="p-8 max-w-[1200px] mx-auto">
                        {error && (
                            <div className="p-4 bg-red-50 text-red-700 rounded-xl mt-4 flex gap-2">
                                <AlertCircle size={18} />
                                {error}
                            </div>
                        )}

                        <div className="bg-white rounded-[2.5rem] p-10 border border-gray-200 shadow-sm space-y-8">
                            <h2 className="text-xl font-black flex items-center gap-2">
                                <ShieldAlert className="text-blue-600" size={24} />
                                Penalty Configuration
                            </h2>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                                <CustomSelect
                                    label="Fee Type"
                                    options={feeTypeOptions}
                                    value={formData.fee_type}
                                    onChange={value => handleChange("fee_type", value)}
                                />

                                <CustomSelect
                                    label="Penalty Type"
                                    options={penaltyTypeOptions}
                                    value={formData.penalty_type}
                                    onChange={value => handleChange("penalty_type", value)}
                                />

                                <Input
                                    label="Penalty Value"
                                    type="number"
                                    value={formData.penalty_value}
                                    onChange={e => handleChange("penalty_value", e.target.value)}
                                />

                                <Input
                                    label="Applies After Days"
                                    type="number"
                                    value={formData.applies_after_days}
                                    onChange={e => handleChange("applies_after_days", e.target.value)}
                                />

                                <CustomSelect
                                    label="Frequency"
                                    options={frequencyOptions}
                                    value={formData.frequency}
                                    onChange={value => handleChange("frequency", value)}
                                />

                                <CustomSelect
                                    label="Status"
                                    options={statusOptions}
                                    value={formData.is_active}
                                    onChange={value => handleChange("is_active", value)}
                                />

                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </AdminLayout>
    );
};

export default CreatePenalty;
