import React, { useState, useEffect } from 'react';
import AdminLayout from '../../layouts/AdminLayout';

const FamilyListing = () => {
    return (
        <AdminLayout> </AdminLayout>
    );
};

export default FamilyListing;
